/**
 * useClickTracker — sends every significant user interaction
 * to the DDoS Shield backend (/track endpoint).
 *
 * Usage:
 *   import useClickTracker from '../hooks/useClickTracker'
 *   useClickTracker('PageName')
 */

import { useEffect, useCallback } from 'react'

const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || 'http://localhost:8080'

// Elements we care about tracking
const TRACKABLE_SELECTORS = [
  'a', 'button', 'input[type="submit"]', 'input[type="button"]',
  '[role="button"]', '[role="link"]', '[role="menuitem"]',
  '[data-track]', 'nav a', '.service-card', 'form button',
]

function getElementLabel(el) {
  // Try various ways to get a meaningful label
  return (
    el.getAttribute('data-track') ||
    el.getAttribute('aria-label') ||
    el.textContent?.trim().slice(0, 60) ||
    el.getAttribute('href') ||
    el.getAttribute('name') ||
    el.tagName.toLowerCase()
  )
}

function isTrackable(el) {
  return TRACKABLE_SELECTORS.some(sel => el.matches?.(sel) || el.closest?.(sel))
}

export default function useClickTracker(pageName = 'unknown') {
  const track = useCallback(
    async (element, eventType = 'click') => {
      try {
        await fetch(`${BACKEND_URL}/track`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            page:    pageName,
            element: element,
            event:   eventType,
            ts:      new Date().toISOString(),
          }),
        })
      } catch (_) {
        // Silently fail — never break the UI
      }
    },
    [pageName]
  )

  useEffect(() => {
    function handleClick(e) {
      const el = e.target
      if (!el) return

      // Walk up to find a trackable ancestor
      let target = el
      for (let i = 0; i < 5; i++) {
        if (!target) break
        if (isTrackable(target)) {
          track(getElementLabel(target), 'click')
          return
        }
        target = target.parentElement
      }
      // Still track generic clicks with tag info
      track(`${el.tagName?.toLowerCase() || 'unknown'}`, 'click')
    }

    document.addEventListener('click', handleClick, { passive: true })
    return () => document.removeEventListener('click', handleClick)
  }, [track])
}
